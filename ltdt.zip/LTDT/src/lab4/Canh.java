package lab4;

public class Canh implements Comparable<Canh> {
	private String name;
	private int diem1;
	private int diem2;
	private int trongSo;

	

	public Canh(String name, int diem1, int diem2, int trongSo) {
		super();
		this.name = name;
		this.diem1 = diem1;
		this.diem2 = diem2;
		this.trongSo = trongSo;
	}

	public int getDiem1() {
		return diem1;
	}

	public int getDiem2() {
		return diem2;
	}

	public int getTrongSo() {
		return trongSo;
	}

	@Override
	public int compareTo(Canh o) {
		// TODO Auto-generated method stub
		if (trongSo > o.trongSo) {
			return 1;
		}
		if (trongSo < o.trongSo) {
			return -1;
		}
		return 0;
	}
	

	public String getName() {
		return name;
	}

	public boolean ke(Canh other) {
		if (diem1 == other.diem1 && diem2 == other.diem2 || diem2 == other.diem1 && diem1 == other.diem2) {
			return false;
		}
		if (diem1 == other.diem1 || diem1 == other.diem2 || diem2 == other.diem1 || diem2 == other.diem2) {
			return true;
		} else
			return false;

	}

}
