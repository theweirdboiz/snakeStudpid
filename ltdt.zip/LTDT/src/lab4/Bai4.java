package lab4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Bai4 {
	private int soDinh;
	private ArrayList<Canh> listCanhCuaKhung;
	private ArrayList<Canh> listCanh;
	private ArrayList<Canh> sortList;
	private int[] chuaXetKruskal;
	private ArrayList<ArrayList<Integer>> listDinhKe;
	private ArrayList<ArrayList<Canh>> listCanhKe;
	private ArrayList<Integer> listDinhPrim;

	public Bai4(ArrayList<Canh> listCanh, int soDinh) {
		// TODO Auto-generated constructor stub
		this.soDinh = soDinh;
		this.listCanh = listCanh;
	}

///////////////////////////// phương thức chung ///////////////////////////////////////
	public void listDinhKeInit() {
		listDinhKe = new ArrayList<ArrayList<Integer>>();
		for (int i = 0; i < soDinh; i++) {
			ArrayList<Integer> array = new ArrayList<Integer>();
			for (int j = 0; j < listCanh.size(); j++) {
				if (listCanh.get(j).getDiem1() == i) {
					array.add(listCanh.get(j).getDiem2());
				}
				if (listCanh.get(j).getDiem2() == i) {
					array.add(listCanh.get(j).getDiem1());
				}
			}
			listDinhKe.add(array);
		}

	}

	public void listCanhKeInit() {
		listCanhKe = new ArrayList<ArrayList<Canh>>();
		for (int i = 0; i < soDinh; i++) {
			ArrayList<Canh> array = new ArrayList<Canh>();
			for (int j = 0; j < listCanh.size(); j++) {
				if (listCanh.get(j).getDiem1() == i || listCanh.get(j).getDiem2() == i) {
					array.add(listCanh.get(j));
				}
			}
//			System.out.print(i+" ");
//			print(array);
//			System.out.println();

		}
	}

	public void listCanhKhungInit() {
		listCanhCuaKhung = new ArrayList<Canh>();
	}

	public void sortListInit(ArrayList<Canh> listCanh) {
		sortList = new ArrayList<Canh>();
		for (int i = 0; i < listCanh.size(); i++) {
			sortList.add(listCanh.get(i));
		}
		Collections.sort(sortList);
	}

	public void print(List<Canh> a) {
		for (int i = 0; i < a.size(); i++) {
			System.out.print("( " + a.get(i).getDiem1() + " " + a.get(i).getDiem2() + " )" + " ");
		}
	}
///////////////////////////////////// Prim ////////////////////////////////////////////////////////////

	public boolean taoChuTrinhPrim(ArrayList<Integer> listDinhPrim, Canh e) {
		if (listDinhPrim.contains(e.getDiem1()) && !listDinhPrim.contains(e.getDiem2())
				|| listDinhPrim.contains(e.getDiem2()) && !listDinhPrim.contains(e.getDiem1())) {
			return false;
		} else {
			return true;
		}
	}

	public void prim(int i) {
		ArrayList<Canh> listCanhPrim;
		listDinhPrim = new ArrayList<Integer>();
		listCanhKhungInit();
		listDinhKeInit();
		listCanhKeInit();
		listDinhPrim.add(i);
		while (listCanhCuaKhung.size() < listCanh.size() - 1 && listDinhPrim.size() < soDinh) {
			listCanhPrim = new ArrayList<Canh>();
			for (int j = 0; j < listCanh.size(); j++) {
				if (!taoChuTrinhPrim(listDinhPrim, listCanh.get(j)) && !listCanhCuaKhung.contains(listCanh.get(j))) {
					listCanhPrim.add(listCanh.get(j));
				}
			}
			sortListInit(listCanhPrim);
			Canh e = sortList.remove(0);
			if (!listDinhPrim.contains(e.getDiem1())) {
				listDinhPrim.add(e.getDiem1());
			}
			if (!listDinhPrim.contains(e.getDiem2())) {
				listDinhPrim.add(e.getDiem2());
			}
			listCanhCuaKhung.add(e);
		}
		print(listCanhCuaKhung);
	}

////////////////////////////////////   Kruskal  /////////////////////////////////////////////////////////////
	public int soNhoHon(int a, int b) {
		if (a > b) {
			return b;
		} else {
			return a;
		}
	}

	public int soLonHon(int a, int b) {
		if (a > b) {
			return a;
		} else {
			return b;
		}
	}

	public void updateArray(int[] array, int a, int da, int b, int db, int count) {
		if (a == 0 && b == 0) {
			array[da] = count;
			array[db] = count;
		} else if (a == 0 && b != 0 || a != 0 && b == 0) {
			if (a == 0) {
				array[da] = b;
			}
			if (b == 0) {
				array[db] = a;
			}
		} else if (a != b) {
			a = soNhoHon(a, b);
			for (int i = 0; i < array.length; i++) {
				if (array[i] == soLonHon(a, b)) {
					array[i] = soNhoHon(a, b);
				}
			}
			b = soNhoHon(a, b);
		}
//		System.out.print(a+" "+b+ " "+ Arrays.toString(array));
	}

	public void chuaXetKruskalInit() {
		chuaXetKruskal = new int[listCanh.size()];
		for (int i = 0; i < chuaXetKruskal.length; i++) {
			chuaXetKruskal[i] = 0;
		}
	}

	public boolean taoChuTrinhKruskal(Canh i) {
		if (chuaXetKruskal[i.getDiem1()] == 0 || chuaXetKruskal[i.getDiem2()] == 0) {
			return false;
		}
		if (chuaXetKruskal[i.getDiem1()] != chuaXetKruskal[i.getDiem2()]) {
			return false;
		}
		return true;
	}

	public void kruskal() {
		sortListInit(listCanh);
		listCanhKhungInit();
		chuaXetKruskalInit();
		Canh e;
		int count = 1;
		e = sortList.remove(0);
		chuaXetKruskal[e.getDiem1()] = count;
		chuaXetKruskal[e.getDiem2()] = count;
		listCanhCuaKhung.add(e);
//		System.out.println(Arrays.toString(chuaXetKruskal));
		while (listCanhCuaKhung.size() < listCanh.size() - 1 && sortList.size() != 0) {
//			System.out.println();
			e = sortList.remove(0);
			if (!taoChuTrinhKruskal(e)) {
				count++;
				updateArray(chuaXetKruskal, chuaXetKruskal[e.getDiem1()], e.getDiem1(), chuaXetKruskal[e.getDiem2()],
						e.getDiem2(), count);
				listCanhCuaKhung.add(e);
			}
//			System.out.println(Arrays.toString(chuaXetKruskal));
		}
		print(listCanhCuaKhung);
//		System.out.println();
//		System.out.println(Arrays.toString(chuaXetKruskal));

	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) {
		Canh a = new Canh("a", 0, 1, 12);
		Canh b = new Canh("b", 1, 2, 24);
		Canh c = new Canh("c", 2, 3, 5);
		Canh d = new Canh("d", 3, 4, 1);
		Canh e = new Canh("e", 4, 5, 20);
		Canh f = new Canh("f", 5, 1, 4);
		Canh g = new Canh("g", 4, 2, 7);
		Canh h = new Canh("h", 5, 0, 3);
		ArrayList<Canh> listCanh = new ArrayList<Canh>();
		listCanh.add(a);
		listCanh.add(b);
		listCanh.add(c);
		listCanh.add(d);
		listCanh.add(e);
		listCanh.add(f);
		listCanh.add(g);
		listCanh.add(h);
		Bai4 b4 = new Bai4(listCanh, 6);
//		System.out.println(b4.listCanh.get(0).ke(c));
		b4.kruskal();
		System.out.println();
		b4.prim(3);

	}
}
