package lab2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class bai2 {
	static ArrayList<ArrayList<Integer>> mtk = new ArrayList<ArrayList<Integer>>();
	static ArrayList<ArrayList<Integer>> ke = new ArrayList<ArrayList<Integer>>();
	static ArrayList<Boolean> chuaXet = new ArrayList<Boolean>();

	public static void themDinh(ArrayList<ArrayList<Integer>> mtk) {
		if (mtk.size() == 0) {
			mtk.add(new ArrayList<Integer>());
			mtk.get(0).add(0);
			return;
		}
		for (int i = 0; i < mtk.size(); i++) {
			mtk.get(i).add(0);
		}
		ArrayList<Integer> dongmoi = new ArrayList<Integer>();
		for (int i = 0; i < mtk.size() + 1; i++) {
			dongmoi.add(0);
		}
		mtk.add(dongmoi);
	}

	public static void themCanh(ArrayList<ArrayList<Integer>> mtk, int diemdau1, int diemdau2) {
		if (diemdau1 == diemdau2) {
			System.out.println("ko thể tạo cạnh này");
		}
		mtk.get(diemdau1).set(diemdau2, 1);
		mtk.get(diemdau2).set(diemdau1, 1);
	}

	public static boolean ke(int x, int y) {
		if (mtk.get(x).get(y) == 1) {
			return true;
		} else
			return false;
	}

	public static void DFS(int i) {
		Stack<Integer> stack = new Stack<Integer>();
		ArrayList<Integer> array = new ArrayList<Integer>();
		stack.push(i);
		OUTER: while (!stack.isEmpty()) {
			int p = stack.pop();
			if (chuaXet.get(p) == false) {
				while (chuaXet.get(p) == false) {
					if (!stack.isEmpty()) {
						p = stack.pop();
					}
					if (stack.isEmpty()) {
						break OUTER;
					}
				}
			}
			chuaXet.set(p, false);
			array.add(p);
			for (int j = 0; j < ke.get(p).size(); j++) {
				if (chuaXet.get(ke.get(p).get(j))) {
					stack.push(ke.get(p).get(j));
				}
			}
		}
		System.out.println(array);
	}

	public static void BFS(int i) {
		Queue<Integer> queue = new LinkedList<Integer>();
		ArrayList<Integer> array = new ArrayList<Integer>();
		queue.add(i);
		chuaXet.set(i, false);
		array.add(i);
		while (!queue.isEmpty()) {
			int p = queue.poll();
			for (int j = 0; j < ke.get(p).size(); j++) {
				if (chuaXet.get(ke.get(p).get(j))) {
					queue.add(ke.get(p).get(j));
					chuaXet.set(ke.get(p).get(j), false);
					array.add(ke.get(p).get(j));
				}
			}
		}
		System.out.println(array);
	}

	public static void main(String[] args) {
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themCanh(mtk, 0, 1);
		themCanh(mtk, 0, 3);
		themCanh(mtk, 1, 2);
		themCanh(mtk, 1, 4);
		themCanh(mtk, 2, 3);
		themCanh(mtk, 2, 4);
		themCanh(mtk, 2, 7);
		themCanh(mtk, 3, 6);
		themCanh(mtk, 6, 5);
		for (int i = 0; i < mtk.size(); i++) {
			ke.add(new ArrayList<Integer>());
		}
		// thêm nội dung cho danh sách kề
		for (int i = 0; i < ke.size(); i++) {
			for (int j = 0; j < mtk.size(); j++) {
				if (ke(i, j) == true)
					ke.get(i).add(j);
			}
		}
		// tất cả các đỉnh đều có chuaXet=true;
		for (int i = 0; i < mtk.size(); i++) {
			chuaXet.add(true);
		}
		////////////////////////////////////////////////////////////////
		BFS(2);
		for (int i = 0; i < mtk.size(); i++) {
			chuaXet.set(i, true);
		}
		DFS(2);

	}
}
