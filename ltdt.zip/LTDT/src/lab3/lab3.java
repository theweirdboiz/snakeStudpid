package lab3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class lab3 {
	static ArrayList<ArrayList<Integer>> mtk = new ArrayList<ArrayList<Integer>>();
	static ArrayList<ArrayList<Integer>> ke = new ArrayList<ArrayList<Integer>>();
	static ArrayList<Boolean> chuaXet = new ArrayList<Boolean>();

	public static void themDinh(ArrayList<ArrayList<Integer>> mtk) {
		if (mtk.size() == 0) {
			mtk.add(new ArrayList<Integer>());
			mtk.get(0).add(0);
			return;
		}
		for (int i = 0; i < mtk.size(); i++) {
			mtk.get(i).add(0);
		}
		ArrayList<Integer> dongmoi = new ArrayList<Integer>();
		for (int i = 0; i < mtk.size() + 1; i++) {
			dongmoi.add(0);
		}
		mtk.add(dongmoi);
	}

	public static void themCanh(ArrayList<ArrayList<Integer>> mtk, int diemdau1, int diemdau2) {
		if (diemdau1 == diemdau2) {
			System.out.println("ko thể tạo cạnh này");
		}
		mtk.get(diemdau1).set(diemdau2, 1);
		mtk.get(diemdau2).set(diemdau1, 1);
	}

	public static boolean ke(ArrayList<ArrayList<Integer>> mtk,int x, int y) {
		if (mtk.get(x).get(y) == 1) {
			return true;
		} else
			return false;
	}

	public static void DFS(ArrayList<ArrayList<Integer>> mtk, int i) {
		Stack<Integer> stack = new Stack<Integer>();
		ArrayList<Integer> array = new ArrayList<Integer>();
		stack.push(i);
		OUTER: while (!stack.isEmpty()) {
			int p = stack.pop();
			if (chuaXet.get(p) == false) {
				while (chuaXet.get(p) == false) {
					if (!stack.isEmpty()) {
						p = stack.pop();
					}
					if (stack.isEmpty()) {
						break OUTER;
					}
				}
			}
			chuaXet.set(p, false);
			array.add(p);
			for (int j = 0; j < ke.get(p).size(); j++) {
				if (chuaXet.get(ke.get(p).get(j))) {
					stack.push(ke.get(p).get(j));
				}
			}
		}
		System.out.println(array);
	}

	public static void BFS(ArrayList<ArrayList<Integer>> mtk, int i) {
		Queue<Integer> queue = new LinkedList<Integer>();
		queue.add(i);
		chuaXet.set(i, false);
		while (!queue.isEmpty()) {
			int p = queue.poll();
			for (int j = 0; j < ke.get(p).size(); j++) {
				if (chuaXet.get(ke.get(p).get(j))) {
					queue.add(ke.get(p).get(j));
					chuaXet.set(ke.get(p).get(j), false);
				}
			}
		}
	}

	public static void timDuongDiDFS(ArrayList<ArrayList<Integer>> mtk, int i, int k) {
		int[] truoc = new int[mtk.size()];
		Queue<Integer> queue = new LinkedList<Integer>();
		ArrayList<Integer> array = new ArrayList<Integer>();
		queue.add(i);
		chuaXet.set(i, false);
		array.add(i);
		while (!queue.isEmpty()) {
			int p = queue.poll();
			for (int j = 0; j < ke.get(p).size(); j++) {
				if (chuaXet.get(ke.get(p).get(j))) {
					queue.add(ke.get(p).get(j));
					chuaXet.set(ke.get(p).get(j), false);
					truoc[ke.get(p).get(j)] = p;
					array.add(ke.get(p).get(j));
				}
			}
		}
		if (chuaXet.get(k) == true) {
			System.out.println("không có đường đi từ " + i + " đến " + k);
		} else {
			int v = k;
			while (v != i) {
				System.out.print(v + " ");
				v = truoc[v];
			}
			System.out.print(i);
			System.out.println();
		}
	}

	public static void timDuongDiBFS(ArrayList<ArrayList<Integer>> mtk, int i, int k) {
		int[] truoc = new int[mtk.size()];
		Queue<Integer> queue = new LinkedList<Integer>();
		ArrayList<Integer> array = new ArrayList<Integer>();
		queue.add(i);
		chuaXet.set(i, false);
		array.add(i);
		while (!queue.isEmpty()) {
			int p = queue.poll();
			for (int j = 0; j < ke.get(p).size(); j++) {
				if (chuaXet.get(ke.get(p).get(j))) {
					queue.add(ke.get(p).get(j));
					chuaXet.set(ke.get(p).get(j), false);
					truoc[ke.get(p).get(j)] = p;
					array.add(ke.get(p).get(j));
				}
			}
		}
		if (chuaXet.get(k) == true) {
			System.out.println("không có đường đi từ " + i + " đến " + k);
		} else {

			int v = k;
			while (v != i) {
				System.out.print(v + " ");
				v = truoc[v];
			}
			System.out.print(i);
			System.out.println();
		}
	}

	public static boolean timDuongDiBFSBoolean(ArrayList<ArrayList<Integer>> mtk, int i, int k) {
		initKeVaChuaXet(mtk);
		BFS(mtk, i);
		if (chuaXet.get(k) == true) {
			return false;
		} else {
			return true;
		}
	}

	public static void initKeVaChuaXet(ArrayList<ArrayList<Integer>> mtk) {
		chuaXet = new ArrayList<Boolean>();
		for (int i = 0; i < mtk.size(); i++) {
			chuaXet.add(true);
		}
		
		//////////////////////////////////////
		for (int i = 0; i < mtk.size(); i++) {
			ke.add(new ArrayList<Integer>());
		}
		// thêm nội dung cho danh sách kề
		for (int i = 0; i < mtk.size(); i++) {
			for (int j = 0; j < mtk.size(); j++) {
				if (ke(mtk,i, j) == true)
					ke.get(i).add(j);
			}
		}
	}

	public static boolean kiemTraVoHuong(ArrayList<ArrayList<Integer>> mtk) {
		for (int i = 0; i < mtk.size(); i++) {
			for (int j = 0; j < mtk.size(); j++) {
				if (mtk.get(i).get(j) == 1 && mtk.get(j).get(i) != 1) {
					return false;
				}
			}
		}
		return true;
	}

	public static boolean kiemTraLienThongBoolean(ArrayList<ArrayList<Integer>> mtk) {
		for (int i = 0; i < mtk.size(); i++) {
			for (int j = 0; j < mtk.size(); j++) {
				if (timDuongDiBFSBoolean(mtk, i, j) == false) {
					System.out.println(i + " " + j);
					return false;
				}
			}
		}
		return true;
	}

	public static ArrayList<ArrayList<Integer>> chuyenDoiSangVoHuong(ArrayList<ArrayList<Integer>> mtk) {
		ArrayList<ArrayList<Integer>> vohuong = (ArrayList<ArrayList<Integer>>) mtk.clone();
		for (int i = 0; i < mtk.size(); i++) {
			for (int j = 0; j < mtk.size(); j++) {
				if (mtk.get(i).get(j) == 1) {
					vohuong.get(j).set(i, 1);
				}
			}
		}
		return vohuong;

	}

	public static void kiemTraLienThong(ArrayList<ArrayList<Integer>> mtk) {
		if (kiemTraVoHuong(mtk) && kiemTraLienThongBoolean(mtk)) {
			System.out.println("Liên Thông Vô Hướng");
		}
		if (kiemTraVoHuong(mtk) == false && kiemTraLienThongBoolean(mtk) == true) {
			System.out.println("Liên Thông Mạnh");
		}
		if (kiemTraVoHuong(mtk) == false && kiemTraLienThongBoolean(mtk) == false
				&& kiemTraLienThongBoolean(chuyenDoiSangVoHuong(mtk)) == true) {
			System.out.println("Liên Thông Yếu");
		}
		if (kiemTraVoHuong(mtk) && kiemTraLienThongBoolean(mtk) == false || kiemTraVoHuong(mtk) == false
				&& kiemTraLienThongBoolean(mtk) == false && kiemTraLienThongBoolean(mtk) == false
				&& kiemTraLienThongBoolean(chuyenDoiSangVoHuong(mtk)) == false) {
			System.out.println("Không Liên Thông");
		}
	}

	public static void main(String[] args) {
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themCanh(mtk, 0, 1);
		themCanh(mtk, 0, 3);
		themCanh(mtk, 1, 2);
		themCanh(mtk, 3, 2);
		themCanh(mtk, 2, 4);
		
//////// tạo cạnh có hướng ///////////
		// test liên thông yếu
//		mtk.get(4).set(2, 0);
		
		// test Liên thông Mạnh
//		mtk.get(0).set(1,0 );
		
		//test không liên thông
		// cách 1:thêm đỉnh
//		themDinh(mtk);
		//cách 2: hủy cạnh tạo đỉnh cô lập
//		mtk.get(0).set(1, 0);
//		mtk.get(1).set(0, 0);
//		mtk.get(2).set(1, 0);
//		mtk.get(1).set(2, 0);
		

///////////   Test   //////////
		//câu 1
		initKeVaChuaXet(mtk);
		timDuongDiDFS(mtk, 0, 1);
		initKeVaChuaXet(mtk);
		timDuongDiBFS(mtk, 0, 4);
		System.out.println("/////////////////");
		
		/////////////////////////////
		//câu 2
		initKeVaChuaXet(mtk);
		System.out.println(kiemTraVoHuong(mtk));
		System.out.println("/////////////////");
		
		
		////////////////////////////
		// câu 3
		initKeVaChuaXet(mtk);
		kiemTraLienThong(mtk);

	}

}
