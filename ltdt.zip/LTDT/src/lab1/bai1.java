package lab1;


import java.util.ArrayList;

public class bai1 {
	public static void themDinh(ArrayList<ArrayList<String>> mtk) {
		if (mtk.size() == 0) {
			mtk.add(new ArrayList<String>());
			mtk.get(0).add("0");
			return;
		}
		for (int i = 0; i < mtk.size(); i++) {
			mtk.get(i).add("0");
		}
		ArrayList<String> dongmoi = new ArrayList<String>();
		for (int i = 0; i < mtk.size() + 1; i++) {
			dongmoi.add("0");
		}
		mtk.add(dongmoi);
	}

	public static void in(ArrayList<ArrayList<String>> mtk) {
		for (int i = 0; i < mtk.size(); i++) {
			for (int j = 0; j < mtk.size(); j++)

			{
				System.out.print(mtk.get(i).get(j) + " ");
			}
			System.out.println();
		}
	}

	public static void themCanh(ArrayList<ArrayList<String>> mtk, int diemdau1, int diemdau2) {
		if (diemdau1==diemdau2) {
			System.out.println("ko thể tạo cạnh này");
		}
		mtk.get(diemdau1).set(diemdau2, "A");
		mtk.get(diemdau2).set(diemdau1, "A");
	}
	public static int bac (ArrayList<ArrayList<String>> mtk, int i) {
		int count =0;
		for (int j = 0; j < mtk.get(i).size(); j++) {
			if (mtk.get(i).get(j).equals("A")) {
				count++;
			}
		}
		return count;
	}
	public static int soCanh (ArrayList<ArrayList<String>> mtk) {
		int sum=0;
		for (int i = 0; i < mtk.size(); i++) {
			sum+=bac(mtk, i);
		}
		return sum/2;
	}
	public static boolean ke(ArrayList<ArrayList<String>> mtk, int x, int y) {
		if (mtk.get(x).get(y).equals("A")) {
			return true;
		}else
			return false;
	}
	public static ArrayList<String> danhSachKe (ArrayList<ArrayList<String>> mtk, int i){
		ArrayList<String> list = new ArrayList<String>();
		for (int j = 0; j < mtk.size(); j++) {
			if (ke(mtk, i, j)) {
				list.add(String.valueOf(j));
			}
		}
		return list;
	}

	public static void main(String[] args) {

		ArrayList<ArrayList<String>> mtk = new ArrayList<ArrayList<String>>();
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themDinh(mtk);
		themCanh(mtk, 0, 1);
		themCanh(mtk, 0, 3);
		themCanh(mtk, 1, 2);
		themCanh(mtk, 3, 2);
		themDinh(mtk);
//		System.out.println(bac(mtk, 1));
//		System.out.println(soCanh(mtk));
//		System.out.println(ke(mtk, 2, 1));
		System.out.println(danhSachKe(mtk, 3));
		in(mtk);
	}
}
